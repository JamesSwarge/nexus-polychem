document.addEventListener("DOMContentLoaded",(function(){document.querySelectorAll(".dropdown-menu").forEach((function(n){n.addEventListener("click",(function(n){n.stopPropagation()}))})),window.innerWidth}));
//# sourceMappingURL=about.eae89268.js.map
